Add real screenshots from your own lab here. Suggested evidence is listed in the root README. Redact sensitive information before committing.
