Store only sanitized, non-secret configuration examples here. Never commit passwords, tokens, private keys, agent keys, or certificates.
